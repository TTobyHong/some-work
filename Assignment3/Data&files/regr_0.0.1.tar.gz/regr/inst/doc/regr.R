## ------------------------------------------------------------------------
library(regr)

# linear regression
regr::reg

regr:::regFit

## ------------------------------------------------------------------------
print
getS3method("print", "reg")

## ------------------------------------------------------------------------
summary
getS3method("summary", "reg")

## ------------------------------------------------------------------------
coef
getS3method("coef", "default")

## ------------------------------------------------------------------------
fitted
getS3method("fitted", "default")
getS3method("napredict", "default")

## ------------------------------------------------------------------------
residuals
getS3method("residuals", "default")
getS3method("naresid", "default")

## ------------------------------------------------------------------------
predict
getS3method("predict", "reg")

## ------------------------------------------------------------------------
library(ggplot2)

fit_reg <- reg(hwy ~ displ, data=mpg)
summary(fit_reg)

fit_lm <- lm(hwy ~ displ, data=mpg)
summary(fit_lm)

## ------------------------------------------------------------------------
mpg %>%
  add_predictions(fit_reg) %>%
  ggplot(aes(x=displ)) +
  geom_point(aes(y=hwy)) +
  geom_line(aes(y=pred), color="red")

## ------------------------------------------------------------------------
mpg %>%
  add_residuals(fit_reg) %>%
  ggplot(aes(x=displ, y=resid)) +
  geom_point()

## ------------------------------------------------------------------------
fit2_reg <- reg(hwy ~ displ + drv + class, data=mpg)
summary(fit2_reg)

fit2_lm <- lm(hwy ~ displ + drv + class, data=mpg)
summary(fit2_lm)

## ------------------------------------------------------------------------
mpg %>%
  add_residuals(fit2_reg) %>%
  ggplot(aes(x=displ, y=resid)) +
  geom_point()

## ------------------------------------------------------------------------
mpg %>%
  add_residuals(fit2_reg) %>%
  ggplot(aes(x=displ, y=resid, color=fl)) +
  geom_point()

