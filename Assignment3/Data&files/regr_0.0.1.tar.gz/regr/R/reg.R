
#' regr: Linear regression
#'
#' The regr package implement basic linear regression
#'
#' @docType package
#' @name regr
#' 
#' @import stats
#' @import modelr
NULL

#' Linear regression
#'
#' \code{reg} fits a linear regression model.
#'
#' @param formula The model formula.
#' @param data The data to use.
#' 
#' @return An object of class \code{reg}.
#' 
#' @examples
#' library(datasets)
#' reg(mpg ~ disp, data=mtcars)
#' 
#' @export
reg <- function(formula, data) {
  regFit(fm=as.formula(formula), data=data)
}

# Internal function for fitting linear regression
#
regFit <- function(fm, data) {
  call <- match.call()
  if ( as.character(fm[[1]]) != "~" )
    stop("invalid formula")
  y_names <- all.vars(fm[[2]])
  x_names <- all.vars(fm[[3]])
  Y <- as.matrix(data[,y_names,drop=FALSE])
  n <- nrow(Y)
  X <- model.matrix(fm, data)
  p <- ncol(X)
  B <- solve(t(X) %*% X) %*% (t(X) %*% Y)
  Yhat <- X %*% B
  resid <- as.vector(Y - Yhat)
  MSE <- sum(resid^2) / (n - p)
  se <- sqrt(MSE * diag(solve(t(X) %*% X)))
  coef <- as.vector(B)
  t.stats <- coef / se
  p.value <- 2 * pt(-abs(t.stats), n - p)
  names(coef) <- rownames(B)
  structure(list(x=X, y=as.vector(Y), nobs=n, coefficients=coef,
                 fitted.values=as.vector(Yhat), residuals=resid,
                 MSE=MSE, se=se, t.stats=t.stats,
                 p.value=p.value, call=call, formula=fm),
            class="reg")
}

#' @describeIn reg Print method for reg objects
#' 
#' @param x The object to be printed.
#' @param ... Additional arguments.
#' 
#' @method print reg
#' @export
print.reg <- function(x, ...) {
  cat("Call:\n")
  print(x$call)
  cat("\nCoefficients:\n")
  print(x$coefficients)
}

#' @describeIn reg Summary method for reg objects
#' 
#' @param object An appropritate object.
#' 
#' @method summary reg
#' @export
summary.reg <- function(object, ...) {
  cat("Call:\n")
  print(object$call)
  cat("\nResiduals:\n")
  print(summary(object$residuals)[-4]) # no need for mean
  cat("\nCoefficients:\n")
  coef <- data.frame(Estimate=object$coefficients,
                     `Std. Error`=object$se,
                     `t value`=object$t.stats,
                     `Pr(>|t|)`=object$p.value,
                     check.names=FALSE)
  print(coef)
  cat("\nResidual standard error:", sqrt(object$MSE), "on",
      object$nobs - length(object$coefficients), "degrees of freedom\n")
}

#' @describeIn reg Predict method for reg objects
#' 
#' @param newdata New data to use for prediction.
#' 
#' @method predict reg
#' @export
predict.reg <- function(object, newdata, ...) {
  Xnew <- model.matrix(object$formula, newdata)
  B <- as.matrix(object$coefficients)
  as.vector(Xnew %*% B)
}
