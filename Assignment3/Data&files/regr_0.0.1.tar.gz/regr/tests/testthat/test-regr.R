
context("regr - compare with lm")

test_that("reg output matches lm output", {
  
  library(ggplot2)
  
  fit_reg <- reg(hwy ~ displ, data=mpg)
  fit_lm <- lm(hwy ~ displ, data=mpg)
  expect_equivalent(coef(fit_reg), coef(fit_lm))
  
})
