library(testthat)
library(regr)

test_check("regr")
